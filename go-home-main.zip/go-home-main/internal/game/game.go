package game

import (
	telas "go-home/internal/game/scenes"
	"go-home/internal/game/flow"
)

func Game() { //depois vou trazer a cena inicial pra game/scenes, e aqui vai só initializar o jogo
	cena := telas.Cena{
		Largura: 1600,
		Altura:  900,
		Tela:    telas.MENU,
		TileSize: 20,  
        OffsetX:  50,
        OffsetY:  50,
	}
    // instancia do objeto Onibus
	cena.NewFlowFn = func(tileSize int) telas.FlowActions{
		return flow.NewBusFlow(tileSize)
	}

	cena.Gerencia_telas(cena.Tela)
}
