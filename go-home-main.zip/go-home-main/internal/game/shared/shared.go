package shared

import rl "github.com/gen2brain/raylib-go/raylib"

var Cam rl.Camera2D
// pacote intermediario pra evitar import cycle