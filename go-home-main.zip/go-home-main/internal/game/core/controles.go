package mapgen

import rl "github.com/gen2brain/raylib-go/raylib"

const (
    FULLSCREEN = iota
)

var keymap = map[int]int32{
    FULLSCREEN: rl.KeyF11,  //adicionar aqui outras teclas
}

func Acao(acao int) bool {
    tecla, ok := keymap[acao]

    if !ok {
        return false
    }

    return rl.IsKeyPressed(tecla)
}
