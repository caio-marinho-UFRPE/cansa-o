package mapgen

import (
	"math"

	rl "github.com/gen2brain/raylib-go/raylib"
)

// zoom, movimento com gestos, setas

var modo_zoom float32 = 0

func ZoomIn(camera *rl.Camera2D) {

	if rl.IsKeyPressed(rl.KeyOne) {
		modo_zoom = 0
	} else if rl.IsKeyPressed(rl.KeyTwo) {
		modo_zoom = 1
	}

	// if rl.IsMouseButtonDown(rl.MouseButtonLeft) {
	// 	delta := rl.GetMouseDelta()
	// 	delta = rl.Vector2Scale(delta, -1.0/camera.Zoom)
	// 	camera.Target = rl.Vector2Add(camera.Target, delta)
	// }

	if modo_zoom == 0 {
		var rodinha float32 = rl.GetMouseWheelMove()

		if rodinha != 0 {
			mousepos := rl.GetScreenToWorld2D(rl.GetMousePosition(), *camera)
			camera.Offset = rl.GetMousePosition()

			camera.Target = mousepos

			escala := 0.2 * rodinha
			camera.Zoom = float32(clamp( //horrível
				float32(math.Exp(math.Log(float64(camera.Zoom))+float64(escala))),
				0.125, 64.0,
			))

		}
	}
}

func clamp(x, min, max float32) float32 {
	if x < min {
		return min
	}
	if x > max {
		return max
	}
	return x
}
