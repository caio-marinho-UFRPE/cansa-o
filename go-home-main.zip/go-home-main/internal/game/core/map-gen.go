package mapgen

import (
	"math"
	"math/rand"

	rl "github.com/gen2brain/raylib-go/raylib"
)

const (
	TAM_BLOCO = 11
)

// constantes de direcao pra usar na logica de movimento dps
const (
	NORTH = 1
	NE    = 2
	EAST  = 4
	SE    = 8
	SOUTH = 16
	SW    = 32
	WEST  = 64
	NW    = 128
)

type Ponto struct {
	X, Y int
}

// estrutura que define como um bloco eh (grid 11x11 de 0s e 1s)
type PlanoBloco struct {
	ID      int
	Textura rl.Texture2D
	Grid    [TAM_BLOCO][TAM_BLOCO]int
}

// estrutura do bloco ja colocado no mapa (com rotacao e tal)
type InstanciaBloco struct {
	PlanoBlocoID int
	Rotacao      int
	Espelhado    bool
}

// gera o mapa proceduralmente
// retorna: matriz de colisoes (0/1), matriz visual (structs), lista de terminais e paradas
func GerarMapa(larguraEmBlocos, alturaEmBlocos int, blueprints map[int]PlanoBloco) ([][]int, [][]InstanciaBloco, []Ponto, []Ponto) {

	// inicializa matriz visual
	mapaVisual := make([][]InstanciaBloco, alturaEmBlocos)
	for i := range mapaVisual {
		mapaVisual[i] = make([]InstanciaBloco, larguraEmBlocos)
	}

	// calcula tamanho total considerando sobreposicao de bordas (pra nao duplicar rua)
	passo := TAM_BLOCO - 1
	alturaGlobal := (alturaEmBlocos * passo) + 1
	larguraGlobal := (larguraEmBlocos * passo) + 1

	mapaLogico := make([][]int, alturaGlobal)
	for i := range mapaLogico {
		mapaLogico[i] = make([]int, larguraGlobal)
	}

	// prepara lista de IDs pra sortear, dando peso maior pra retas e cruzamentos
	deckDeIds := []int{}
	for id := range blueprints {
		deckDeIds = append(deckDeIds, id)
		if id == 1 {
			deckDeIds = append(deckDeIds, 1, 1, 1)
		}
		if id == 4 {
			deckDeIds = append(deckDeIds, 4, 4)
		}
	}

	// loop principal de preenchimento dos blocos
	for by := 0; by < alturaEmBlocos; by++ {
		for bx := 0; bx < larguraEmBlocos; bx++ {

			idx := rand.Intn(len(deckDeIds))
			idEscolhido := deckDeIds[idx]
			rotacao := rand.Intn(4)
			espelhado := rand.Intn(2) == 1

			mapaVisual[by][bx] = InstanciaBloco{
				PlanoBlocoID: idEscolhido,
				Rotacao:      rotacao,
				Espelhado:    espelhado,
			}

			// pega o grid original e aplica as transformacoes
			blueprint := blueprints[idEscolhido]
			gridProc := blueprint.Grid

			if espelhado {
				gridProc = EspelharMatriz(gridProc)
			}
			gridProc = RotacionarMatriz(gridProc, rotacao)

			// escreve no mapa global com offset pra sobrepor as bordas
			offsetX := bx * passo
			offsetY := by * passo

			for y := 0; y < TAM_BLOCO; y++ {
				for x := 0; x < TAM_BLOCO; x++ {
					// so escreve se for rua (1), pra nao apagar o que o vizinho ja escreveu
					if gridProc[y][x] == 1 {
						mapaLogico[offsetY+y][offsetX+x] = 1
					}
				}
			}
		}
	}

	// posiciona as entidades depois do mapa pronto
	terminais := posicionarTerminais(mapaLogico, larguraGlobal, alturaGlobal)
	paradas := posicionarParadas(mapaLogico, larguraGlobal, alturaGlobal)

	return mapaLogico, mapaVisual, terminais, paradas
}

// conta quantas ruas tem em volta de um ponto (pra saber se eh esquina, reta ou beco)
func contarVizinhosRua(grid [][]int, x, y, largura, altura int) int {
	count := 0
	dirs := [][2]int{{0, -1}, {0, 1}, {-1, 0}, {1, 0}}

	for _, d := range dirs {
		nx, ny := x+d[0], y+d[1]
		if nx >= 0 && nx < largura && ny >= 0 && ny < altura {
			if grid[ny][nx] == 1 {
				count++
			}
		}
	}
	return count
}

// acha 3 pontos distantes pra serem terminais (prefere becos sem saida)
func posicionarTerminais(grid [][]int, largura, altura int) []Ponto {
	candidatos := []Ponto{}

	// acha becos (1 vizinho apenas)
	for y := 0; y < altura; y++ {
		for x := 0; x < largura; x++ {
			if grid[y][x] == 1 {
				if contarVizinhosRua(grid, x, y, largura, altura) == 1 {
					candidatos = append(candidatos, Ponto{X: x, Y: y})
				}
			}
		}
	}

	// fallback se o mapa ficou muito conectado e nao tem beco
	if len(candidatos) < 3 {
		for y := 0; y < altura; y++ {
			for x := 0; x < largura; x++ {
				if grid[y][x] == 1 {
					candidatos = append(candidatos, Ponto{X: x, Y: y})
				}
			}
		}
	}

	terminais := []Ponto{}
	distanciaMinima := 15.0

	rand.Shuffle(len(candidatos), func(i, j int) { candidatos[i], candidatos[j] = candidatos[j], candidatos[i] })

	// seleciona 3 garantindo distancia minima
	for _, cand := range candidatos {
		if len(terminais) >= 3 {
			break
		}
		if len(terminais) == 0 {
			terminais = append(terminais, cand)
			continue
		}

		longe := true
		for _, t := range terminais {
			if calcularDistancia(cand, t) < distanciaMinima {
				longe = false
				break
			}
		}
		if longe {
			terminais = append(terminais, cand)
		}
	}

	// preenche se faltou gente
	if len(terminais) < 3 && len(candidatos) >= 3 {
		for _, cand := range candidatos {
			if len(terminais) >= 3 {
				break
			}
			jaExiste := false
			for _, t := range terminais {
				if t.X == cand.X && t.Y == cand.Y {
					jaExiste = true
					break
				}
			}
			if !jaExiste {
				terminais = append(terminais, cand)
			}
		}
	}

	return terminais
}

// espalha paradas pelo mapa baseado numa frequencia
func posicionarParadas(grid [][]int, largura, altura int) []Ponto {
	paradas := []Ponto{}
	counter := 0
	frequencia := 60 // quanto maior, menos paradas

	for y := 0; y < altura; y++ {
		for x := 0; x < largura; x++ {
			if grid[y][x] == 1 {
				vizinhos := contarVizinhosRua(grid, x, y, largura, altura)

				// so coloca em retas (2 vizinhos) pra nao travar cruzamento
				if vizinhos == 2 {
					counter++
					if counter >= frequencia {
						paradas = append(paradas, Ponto{X: x, Y: y})
						counter = 0
						counter += rand.Intn(10)
					}
				}
			}
		}
	}
	return paradas
}

// func pra criar parada extra em runtime se precisar
func GerarNovaParada(grid [][]int, paradasExistentes []Ponto) (Ponto, bool) {
	largura := len(grid[0])
	altura := len(grid)
	tentativas := 100

	for i := 0; i < tentativas; i++ {
		rx := rand.Intn(largura)
		ry := rand.Intn(altura)

		if grid[ry][rx] != 1 {
			continue
		}
		if contarVizinhosRua(grid, rx, ry, largura, altura) != 2 {
			continue
		}

		ocupado := false
		for _, p := range paradasExistentes {
			if p.X == rx && p.Y == ry {
				ocupado = true
				break
			}
		}
		if ocupado {
			continue
		}

		return Ponto{X: rx, Y: ry}, true
	}
	return Ponto{}, false
}

// func pra criar terminal extra em runtime
func GerarNovoTerminal(grid [][]int, terminaisExistentes []Ponto) (Ponto, bool) {
	largura := len(grid[0])
	altura := len(grid)
	tentativas := 200

	for i := 0; i < tentativas; i++ {
		rx := rand.Intn(largura)
		ry := rand.Intn(altura)

		if grid[ry][rx] != 1 {
			continue
		}
		// tenta achar ponta solta, senao ignora
		if contarVizinhosRua(grid, rx, ry, largura, altura) > 1 {
			continue
		}

		ocupado := false
		for _, t := range terminaisExistentes {
			if t.X == rx && t.Y == ry {
				ocupado = true
				break
			}
		}
		if ocupado {
			continue
		}

		return Ponto{X: rx, Y: ry}, true
	}
	return Ponto{}, false
}

// helpers de matriz
func RotacionarMatriz(original [TAM_BLOCO][TAM_BLOCO]int, rotacoes int) [TAM_BLOCO][TAM_BLOCO]int {
	atual := original
	for r := 0; r < rotacoes; r++ {
		var nova [TAM_BLOCO][TAM_BLOCO]int
		for y := 0; y < TAM_BLOCO; y++ {
			for x := 0; x < TAM_BLOCO; x++ {
				nova[x][TAM_BLOCO-1-y] = atual[y][x]
			}
		}
		atual = nova
	}
	return atual
}

func EspelharMatriz(original [TAM_BLOCO][TAM_BLOCO]int) [TAM_BLOCO][TAM_BLOCO]int {
	var nova [TAM_BLOCO][TAM_BLOCO]int
	for y := 0; y < TAM_BLOCO; y++ {
		for x := 0; x < TAM_BLOCO; x++ {
			nova[y][TAM_BLOCO-1-x] = original[y][x]
		}
	}
	return nova
}

func calcularDistancia(p1, p2 Ponto) float64 {
	return math.Sqrt(math.Pow(float64(p1.X-p2.X), 2) + math.Pow(float64(p1.Y-p2.Y), 2))
}