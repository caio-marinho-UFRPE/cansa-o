package hud

import (
	"fmt"

	rl "github.com/gen2brain/raylib-go/raylib"
)

var menu_lateral_aberto bool = false
var largura_animada float32 = 40
var largura_atual int

var cores [5]rl.Color = [5]rl.Color{ //cores dos assets
	rl.Color{R: 0, G: 183, B: 255, A: 128},
	rl.Color{R: 74, G: 226, B: 61, A: 128},
	rl.Color{R: 225, G: 148, B: 175, A: 128},
	rl.Color{R: 237, G: 40, B: 44, A: 128},
	rl.Color{R: 255, G: 206, B: 0, A: 128},
}

func MenuLateral() {
	altura := rl.GetScreenHeight()
	lagura := 10 * (rl.GetScreenWidth() / 100)
	largura_min := 40

	botaox := rl.GetScreenWidth() - largura_min
	botaoy := 0
	botao_largura := largura_min
	botao_altura := rl.GetScreenHeight()

	if rl.IsMouseButtonPressed(rl.MouseButtonLeft) {
		mousepos := rl.GetMousePosition()

		if mousepos.X > float32(botaox) && mousepos.X < float32(botaox+botao_largura) &&
			mousepos.Y > float32(botaoy) && mousepos.Y < float32(botaoy+botao_altura) {
			menu_lateral_aberto = !menu_lateral_aberto
		}
	}

	velocidade := float32(0.2)
	largura_final := largura_min
	if menu_lateral_aberto {
		largura_final = lagura
	}
	largura_animada = rl.Lerp(largura_animada, float32(largura_final), velocidade)

	if menu_lateral_aberto {
		if menu_lateral_aberto {
			largura_atual = lagura
		} else {
			largura_atual = largura_min
		}
	}

	barra_lateral := rl.Rectangle{
		X:      float32(rl.GetScreenWidth()) - largura_animada,
		Y:      0,
		Width:  largura_animada,
		Height: float32(altura),
	}

	rl.DrawRectangle(int32(barra_lateral.X),
		int32(barra_lateral.Y),
		int32(barra_lateral.Width),
		int32(barra_lateral.Height),
		rl.ColorAlpha(rl.Gray, 0.5),
	)

	rl.DrawRectangle(int32(botaox), int32(botaoy), int32(botao_largura), int32(botao_altura), rl.DarkGray)
	rl.DrawText("<-", int32(botaox)+10, int32(rl.GetScreenHeight()/2)-10, 20, rl.White)
	botoes(&barra_lateral)
}

func botoes(barra_lateral *rl.Rectangle) {
	if menu_lateral_aberto {
		num_botoes := 5
		espaco := 20
		botao_altura := 50
		botao_largura := int(largura_animada) - 2*espaco
		for i := range num_botoes {
			botao_x := int(barra_lateral.X) + espaco
			botao_y := espaco + i*(botao_altura+espaco)
			botao_rect := rl.Rectangle{
				X:      float32(botao_x),
				Y:      float32(botao_y),
				Width:  float32(botao_largura),
				Height: float32(botao_altura),
			}

			// Detecta clique no botão
			mouse := rl.GetMousePosition()
			mouseSobre := mouse.X > botao_rect.X && mouse.X < botao_rect.X+botao_rect.Width &&
				mouse.Y > botao_rect.Y && mouse.Y < botao_rect.Y+botao_rect.Height

			cor := cores[i]
			if mouseSobre {
				cor = rl.Color{R: cores[i].R,G: cores[i].G,B: cores[i].B,A: 255}
				if rl.IsMouseButtonPressed(rl.MouseButtonLeft) {
					// Aqui você pode executar a ação do botão i
					fmt.Println("Linha", i, "clicado!") //no caso vai escolher a cor da linha
				}
			}

			rl.DrawRectangleRec(botao_rect, cor)
			rl.DrawText(fmt.Sprintf("Linha %d", i+1), int32(botao_rect.X)+10, int32(botao_rect.Y)+15, 20, rl.Black)
		}
	}
}
