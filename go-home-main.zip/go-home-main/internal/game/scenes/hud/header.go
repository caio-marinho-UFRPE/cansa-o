package hud

import (
	"fmt"

	rl "github.com/gen2brain/raylib-go/raylib"
)

const (
	ESQUERDA = 0
	TOPO     = 0
	CENTRO   = 1
	MEIO     = 1
	DIREITA  = 2
	BAIXO    = 2
)

func Cabecalho() {
	altura := rl.GetScreenHeight()
	largura := rl.GetScreenWidth()

	barra_superior := rl.Rectangle{
		X:      0,
		Y:      0,
		Width:  float32(largura),
		Height: 5 * (float32(altura)) / 100,
	}

	minutos := int(rl.GetTime()) / 60
	segundos := int(rl.GetTime()) % 60

	rl.DrawRectangleRec(barra_superior, rl.ColorAlpha(rl.Gray, 0.5))

	texto_tempo := fmt.Sprintf("Tempo: %02d:%02d", minutos,segundos)
	texto_tam := float32(rl.MeasureText(texto_tempo, 20))
	fonte := float32(20)

	texto_pos := rl.Vector2{
		X: barra_superior.X + (barra_superior.Width-texto_tam)/2,
		Y: barra_superior.Y + (barra_superior.Height-fonte)/2,
	}

	rl.DrawText(texto_tempo, int32(texto_pos.X), int32(texto_pos.Y), 20, rl.White)
	rl.DrawText("Esquerda", int32(barra_superior.X)+10, int32(barra_superior.Y)+10, 20, rl.White)
	rl.DrawText("Direita", int32(barra_superior.X+barra_superior.Width)-80, int32(barra_superior.Y)+10, 20, rl.White)

	// timer := time.Since(time.Now())
	// rl.DrawText()

} //menu lateral, com seleção de ônibus, linhas e upgrades

func remover() {
}
