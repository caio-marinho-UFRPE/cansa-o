package scenes

import (
	core "go-home/internal/game/core"

	rl "github.com/gen2brain/raylib-go/raylib"
	mapgen "go-home/internal/game/core"
)

const (
	MENU = 1
	GAME = 2
)
// interface contratual (resolve aquele lance do import cycle)
type FlowActions interface{
	RouteBus(mapa [][]int)
	DrawBus()
}

type Cena struct { //adicionar aqui as informações importantes da janela
	Largura int32
	Altura  int32
	Tela    int
	TileSize int32
    OffsetX  int32
    OffsetY  int32
	MapaVisual [][]mapgen.InstanciaBloco
	MapaLogico [][]int
	Terminais  []mapgen.Ponto
    Paradas    []mapgen.Ponto
    Blueprints map[int]mapgen.PlanoBloco
	FlowInstance FlowActions
	NewFlowFn func(tileSize int) FlowActions
}

func (c *Cena) Gerencia_telas(tela int) {
	rl.InitWindow(c.Largura, c.Altura, "GO HOME")
	defer rl.CloseWindow()
	rl.SetTargetFPS(60)
	rl.SetWindowState(rl.FlagWindowResizable)
	rl.SetWindowMinSize(800, 600)

fluxo:
	for !rl.WindowShouldClose() {

		if core.Acao(core.FULLSCREEN) {
			rl.ToggleFullscreen()
		}

		rl.BeginDrawing()
		switch c.Tela {
		case MENU:
			c.abrir_menu()
		case GAME:
			c.abrir_game()
			if c.MapaLogico == nil {
				c.inicializar_game()
			}

			if c.FlowInstance == nil && c.NewFlowFn != nil {
				c.FlowInstance = c.NewFlowFn(int(c.TileSize))
			}

			if c.FlowInstance != nil && c.MapaLogico != nil {
				c.FlowInstance.RouteBus(c.MapaLogico)
				c.FlowInstance.DrawBus()
			}
		default:
			break fluxo
		}
		rl.EndDrawing()
	}
}
