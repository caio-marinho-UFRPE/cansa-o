package scenes

import rl "github.com/gen2brain/raylib-go/raylib"

func (c *Cena) abrir_menu() {

    // título, código repetido da pra ajeitar

    titulo := "GO HOME"
    tam_fonte := int32(84)

    largura_titulo := rl.MeasureText(titulo,tam_fonte)

    posx := int32(rl.GetScreenWidth() - int(largura_titulo)) / 2 //centraliza o texto na tela
    posy := int32(int(tam_fonte))

    rl.DrawText(titulo,posx,posy,tam_fonte,rl.Green)

    // dica

    dica := "Clique Para Iniciar"
    tam_fonte_dica := int32(50)

    largura_dica := rl.MeasureText(dica, tam_fonte_dica)
    posx2 := int32(rl.GetScreenWidth() - int(largura_dica)) / 2
    posy2 := int32(rl.GetScreenHeight() - int(tam_fonte_dica))
    rl.DrawText(dica,posx2,posy2,tam_fonte_dica,rl.Gray)

    rl.ClearBackground(rl.White)

    // ações e botões

    if(rl.IsMouseButtonPressed(rl.MouseButtonLeft)) {
        c.Tela = GAME
    }
}
