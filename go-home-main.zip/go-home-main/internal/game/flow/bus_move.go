package flow

import (
	"math"
	rl "github.com/gen2brain/raylib-go/raylib"
    s "go-home/internal/game/shared"
)

type BusFlow struct{
    path []Pos
    index int
    bus Bus
    speed float32
    tileSize int
    OffsetX int32
    OffsetY int32
}
type Pos struct{ X, Y int }
type Bus struct{ X, Y float32 }

func NewBusFlow (tileSize int) *BusFlow{
    return &BusFlow{
        speed:    1.0,
        tileSize: tileSize,
    }
}

func Reverse(path []Pos) []Pos {
	r := make([]Pos, len(path))
	for i := range path {
		r[i] = path[len(path)-1-i]
	}
	return r
}

func MoveStep(bus *Bus, target Pos, speed float32, tileSize int, mapa [][]int) bool {
	tx := float32(target.X*tileSize + tileSize/2)
    ty := float32(target.Y*tileSize + tileSize/2)

	dx := tx - bus.X
	dy := ty - bus.Y

	dist := float32(math.Sqrt(float64(dx*dx + dy*dy)))

	if dist < 1 {
		bus.X = tx
		bus.Y = ty
		return true
	}

    // Checa se o próximo passo é válido no mapa
    nextX := target.X
    nextY := target.Y

    if mapa[nextY][nextX] != 1 { // 1 = rua
        return false
    }

	bus.X += (dx / dist) * speed
	bus.Y += (dy / dist) * speed

	return false
}

func (f *BusFlow) RouteBus(mapa [][]int) {

    tileSize := f.tileSize

    f.OffsetX = int32(s.Cam.Offset.X)
    f.OffsetY = int32(s.Cam.Offset.Y)

    mouse := rl.GetMousePosition()
    mouse = rl.GetScreenToWorld2D(mouse, s.Cam)
    mouseX := int((mouse.X) / float32(tileSize))
    mouseY := int((mouse.Y) / float32(tileSize))

        // cria o caminho
    if rl.IsMouseButtonDown(rl.MouseLeftButton) {
        if mouseY >= 0 && mouseY < len(mapa) &&
            mouseX >= 0 && mouseX < len(mapa[0]) &&
            mapa[mouseY][mouseX] == 1 {

            p := Pos{mouseX, mouseY}

            // Evita repetir o mesmo tile consecutivamente
            add := true
            if len(f.path) > 0 {
                last := f.path[len(f.path)-1]
                if last.X == p.X && last.Y == p.Y {
                    add = false
                }
            }

            if add {
                f.path = append(f.path, p)
                // O primeiro tile define onde o ônibus começa
                if len(f.path) == 1 {
                    f.bus.X = float32(p.X * tileSize + tileSize/2)
                    f.bus.Y = float32(p.Y * tileSize + tileSize/2)
                }
            }
        }
    }

    // limpa caminho
    if rl.IsMouseButtonPressed(rl.MouseRightButton) {
        f.path = nil
        f.index = 0
    }

    // Mover ônibus seguindo o caminho desenhado
    if len(f.path) > 1 {
        target := f.path[f.index]

        if MoveStep(&f.bus, target, f.speed, tileSize, mapa) {
            f.index++
            if f.index >= len(f.path) {
                f.path = Reverse(f.path)
                f.index = 0
            }
        }
    }
}

func (f *BusFlow) DrawBus (){
    tileSize := f.tileSize
    ox := f.OffsetX
    oy := f.OffsetY

    //desenha o caminho a ser tomado
    for _, p := range f.path{
        px := ox + int32(p.X * tileSize)
        py := oy + int32(p.Y * tileSize)
        rl.DrawRectangleLines(px, py, int32(tileSize), int32(tileSize), rl.Red)
    }
    //desenha o onibus
    if len(f.path) > 0 {
        rl.DrawRectangle(ox + int32(f.bus.X - float32(tileSize)/2),
                         oy + int32(f.bus.Y - float32(tileSize)/2),
                         int32(tileSize), int32(tileSize), rl.Blue)
    }
}
