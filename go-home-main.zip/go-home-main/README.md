# GO Home
Este projeto é dedicado ao desenvolvimento de um jogo de estratégia sobre gerenciar uma malha de transporte público, inspirado nos jogos 'Mini Metro' e 'Mini Motorways'. Em 'GO Home', você deve lidar com o tráfego urbano de uma cidade desenhando as linhas de ônibus que vão levar a população, com recursos limitados, você precisa manter suas linhas eficientes para que todos os passageiros possam chegar ao seu destino sem que se atrasem. Quanto tempo você consegue consegue manter a cidade funcionando? 
---
**Fluxo Principal:**
- Passageiros e Paradas serão representados por formas geométricas, cada passageiro está tentando chegar à parada com a mesma forma que a sua.
- O jogador começa com 3 ônibus com capacidade para 8 passageiros, podendo dispô-los em 3 linhas separadas ou mais de um ônibus na mesma linha.
- Passageiros de qualquer tipo podem surgir em qualquer parada.
- Paradas de tipos específicos podem surgir em qualquer posição do mapa (desde que não seja sobre uma parada já existente ou um rio).
- Paradas tem uma capacidade máxima de 12 passageiros esperando, se houverem mais passageiros em uma parada do que isso, é iniciado um temporizador naquela parada e quando o tempo é esgotado o jogo acaba.
- Paradas ativas por tempo suficiente se tornam paradas BRT, fazendo com que passageiros surjam mais rápido.
- A cada X segundos (pendente definir com o balanceamento do jogo) se passa um dia, após uma semana dentro do jogo, o jogador pode escolher um de dois upgrades. 

**Upgrades:**
- Sanfona - Adiciona um carro adicional ao ônibus.
- Expresso - Ônibus que se movem mais rápido.
- Integração - Aumenta a capacidade máxima de passageiros esperando de uma parada.
- BR - Via expressa conectando dois pontos no mapa.
- Semáforo - Auto explicativo.
- Rotatória - Auto explicativo.
- Ponte - Auto explicativo.
---
- Ilustração para ajudar a entender o projeto proposto.
<img width="1606" height="936" alt="image" src="https://github.com/user-attachments/assets/6d3734f8-21ba-4baa-9571-d62b2fca6d9b" />


## Guia de Configuração (Windows)

Este guia apresenta as instruções essenciais para configurar o ambiente de compilação no Windows, utilizando o MSYS2 e o GCC/G++.

---

### 1. Instalação do MSYS2

1.  Baixe e instale o MSYS2 a partir do site oficial:
    [https://www.msys2.org/](https://www.msys2.org/)

### 2. Instalação do Compilador

1.  Abra o terminal **MSYS2 UCRT64** (busque no Menu Iniciar).
2.  Execute o comando `pacman` para instalar o compilador GCC/G++:

    ```bash
    pacman -S mingw-w64-ucrt-x86_64-gcc
    ```

### 3. Configuração do Compilador no PATH (Obrigatório para Go)

Você precisa definir as variáveis de ambiente `CC` e `CXX` para que o Go saiba onde encontrar o compilador.

> **Nota:** O caminho padrão de instalação do MSYS2 é `C:\msys64`. O executável do compilador estará em `\ucrt64\bin`. Ajuste o caminho nos comandos abaixo se você instalou em outro local.

1.  Abra o **PowerShell** ou **Prompt de Comando (CMD)**.
2.  Defina as variáveis, substituindo o caminho conforme necessário:

    ```bash
    setx CC "C:\msys64\ucrt64\bin\gcc.exe"
    setx CXX "C:\msys64\ucrt64\bin\g++.exe"
    ```
(isso não instala o GCC no PATH do windows, então se quiser usar o GCC no powershell/cmd para outras coisas depois tem que abrir os system environment e configurar lá)

### 4. Compilação do Projeto

1.  Navegue até o diretório clonado deste repositório no seu terminal.
2.  Execute o comando Go para compilar:

    ```bash
    go build -o go-home.exe
    ```

