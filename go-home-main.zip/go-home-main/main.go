package main

import game "go-home/internal/game"

func main() {
    game.Game()
}
