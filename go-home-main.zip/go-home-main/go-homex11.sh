#!/bin/bash

GDK_BACKEND=x11 ./go-home.exe
